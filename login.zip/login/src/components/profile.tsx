import {
  IonItem,
  IonText,
  IonButton,
  IonInput,
  IonLabel,
  IonIcon,
} from "@ionic/react";
import { arrowBackOutline, save } from "ionicons/icons";
import { useState } from "react";
import { useHistory } from "react-router-dom";
interface ContainerProps {}

const Profile: React.FC<ContainerProps> = () => {
  const history = useHistory();
  const [isEdit, setisEdit] = useState(false)
  const goBack = () => {
    console.log("first");
    history.goBack();
  };
  const edit = () => {
    setisEdit(true)
  };
  const save = () => {
    setisEdit(false)
  };
  return (
    <>
      <>
        <div className="flex bg-orange-400">
          <div className="w-2/12 flex justify-start items-center">
            <IonIcon
              icon={arrowBackOutline}
              className="w-8 h-8"
              style={{ color: "white" }}
              onClick={() => goBack()}
            ></IonIcon>
          </div>
          <div className="w-8/12 flex justify-center">
            <IonItem className="text-orange-400" lines="none">
              Profile Screen
            </IonItem>
          </div>
        </div>
        <IonButton fill="outline" onClick={() => edit()}>Edit</IonButton>
        {!isEdit ? (
          <>
            <div className="flex-col mx-3 mt-3">
              <div className="flex">
                <div className="w-6/12">
                  <IonText class="font-bold font-mono">First Name:</IonText>
                </div>
                <div className="w-6/12">
                  <IonText class="font-medium font-mono">John</IonText>
                </div>
              </div>
              <div className="flex">
                <div className="w-6/12">
                  <IonText class="font-bold font-mono">Last Name:</IonText>
                </div>
                <div className="w-6/12">
                  <IonText class="font-medium font-mono">Mike</IonText>
                </div>
              </div>
              <div className="flex">
                <div className="w-6/12">
                  <IonText class="font-bold font-mono">Email:</IonText>
                </div>
                <div className="w-6/12">
                  <IonText class="font-medium font-mono">john.mike@gmail.com</IonText>
                </div>
              </div>
              <div className="flex">
                <div className="w-6/12">
                  <IonText class="font-bold font-mono">Change Password:</IonText>
                </div>
                <div className="w-6/12">
                  <IonText class="font-medium font-mono">*******</IonText>
                </div>
              </div>
              <div className="flex">
                <div className="w-6/12">
                  <IonText class="font-bold font-mono">City:</IonText>
                </div>
                <div className="w-6/12">
                  <IonText class="font-medium font-mono">Not specified</IonText>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="">
              <IonItem class="mx-4">
                <IonLabel position="floating">First Name</IonLabel>
                <IonInput placeholder="Enter your first name"></IonInput>
              </IonItem>
              <IonItem class="mx-4">
                <IonLabel position="floating">Last Name</IonLabel>
                <IonInput placeholder="Enter your last name"></IonInput>
              </IonItem>
              <IonItem class="mx-4">
                <IonLabel position="floating">Email</IonLabel>
                <IonInput placeholder="Enter your email address"></IonInput>
              </IonItem>
              <IonItem class="mx-4">
                <IonLabel position="floating">Password</IonLabel>
                <IonInput placeholder="Enter your password"></IonInput>
              </IonItem>
              <IonItem class="mx-4">
                <IonLabel position="floating">city</IonLabel>
                <IonInput placeholder="Enter your city"></IonInput>
              </IonItem>
              <div className="flex justify-center items-center mt-4">
      <IonButton class="" onClick={()=> save()}> Save</IonButton>
      </div>
            </div>
          </>
        )}
      </>
    </>
  );
};

export default Profile;
