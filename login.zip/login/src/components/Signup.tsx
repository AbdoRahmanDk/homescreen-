import { IonItem, IonLabel, IonInput, IonButton, IonIcon } from "@ionic/react";
import {arrowBackOutline} from "ionicons/icons";
import { useHistory } from "react-router-dom";

interface ContainerProps { }

const Signup: React.FC<ContainerProps> = () => {
const history = useHistory();

const goBack =()=>{
console.log('first')
history.goBack()
}
  return (
    <>
    <div className="flex  bg-indigo-400">
        <div className="w-2/12 flex justify-start items-center">
        <IonIcon icon={arrowBackOutline} className="w-8 h-8" style={{color: "white"}} onClick={() => goBack()}></IonIcon>
        </div>
        <div className="w-8/12 flex justify-center">
        <IonItem className="text-indigo-400" lines="none">
          Signup Screen
        </IonItem>
        </div>
      </div>

    <div className="">
        <IonItem class='mx-4'>
        <IonLabel position="floating">First Name</IonLabel>
        <IonInput placeholder="Enter your first name"></IonInput>
      </IonItem>
      <IonItem class='mx-4'>
        <IonLabel position="floating">Last Name</IonLabel>
        <IonInput placeholder="Enter your last name"></IonInput>
      </IonItem>
      <IonItem class='mx-4'>
        <IonLabel position="floating">Email</IonLabel>
        <IonInput placeholder="Enter your email address"></IonInput>
      </IonItem>
      <IonItem class='mx-4'>
        <IonLabel position="floating">Password</IonLabel>
        <IonInput placeholder="Enter your password"></IonInput>
      </IonItem>
      <IonItem class='mx-4'>
        <IonLabel position="floating">city</IonLabel>
        <IonInput placeholder="Enter your city"></IonInput>
      </IonItem>
      <div className="flex justify-center items-center mt-4">
      <IonButton class=""> Sign up</IonButton>
      </div>
    </div>
    </>
  );
};

export default Signup;
