import { IonItem, IonText, IonButton, IonInput, IonLabel, IonIcon } from "@ionic/react";
import {arrowBackOutline} from "ionicons/icons";
import { useHistory } from "react-router-dom";
interface ContainerProps { }

const Login: React.FC<ContainerProps> = () => {
    const history = useHistory();

    const goBack =()=>{
        console.log('first')
        history.goBack()
        }
  return (
    <>
     <>
      <div className="flex bg-green-400">
        <div className="w-2/12 flex justify-start items-center">
        <IonIcon icon={arrowBackOutline} className="w-8 h-8" style={{color: "white"}} onClick={() => goBack()}></IonIcon>
        </div>
        <div className="w-8/12 flex justify-center">
         <IonItem className="text-green-400" lines="none">
          Login Screen
        </IonItem>
        </div>
            
      </div>
      <IonItem class='mx-4'>
        <IonLabel position="floating">Email</IonLabel>
        <IonInput placeholder="Enter your email address"></IonInput>
      </IonItem>
      <IonItem class='mx-4'>
        <IonLabel position="floating">Password</IonLabel>
        <IonInput placeholder="Enter your password"></IonInput>
      </IonItem>
      <div className="flex justify-center items-center mt-4">
      <IonButton class=""> Login</IonButton>
      </div>
    </>
    </>
  );
};

export default Login;
