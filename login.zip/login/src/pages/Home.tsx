import {
  IonButton,
  IonContent,
  IonHeader,
  IonInput,
  IonItem,
  IonLabel,
  IonPage,
  IonText,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import Login from "../components/Login";
import "./Home.css";

const Home: React.FC = () => {
  return (
    <>
      <div className="flex justify-center items-center bg-blue-400">
        <IonItem className="text-blue-400" lines="none">
          Home Screen
        </IonItem>
      </div>
      <div className="w-full h-10 bg-blue-700 flex justify-center items-center">
        <IonText>
          <h1 className="text-white">Navigation to Login & Signup</h1>
        </IonText>
      </div>
      <div className="flex">
        <div className="w-4/12 flex justify-center items-center">
          <IonButton fill="outline" routerLink="/login">
            Login
          </IonButton>
        </div>
        <div className="w-4/12 flex justify-center items-center">
          <IonButton fill="outline" routerLink="/signup">
            Signup
          </IonButton>
        </div>
        <div className="w-4/12 flex justify-center items-center">
          <IonButton fill="outline" routerLink="/profile">
            Profile
          </IonButton>
        </div>
      </div>
    </>
  );
};

export default Home;
